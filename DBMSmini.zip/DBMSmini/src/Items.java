/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author IYYAPPAN
 */
class Items {
   
  private  int rno;
  private String name;
  private int price;
  private String brname;
  private byte[] image;
  private byte[] logo;
  private String colour;
  private String date;
  private int stock;
  public Items(int rno,String name,int price,String brname,byte[] image,byte[] logo,String colour,String date,int stock)  {
      this.rno=rno;
      this.name=name;
      this.price=price;
      this.brname=brname;
      this.image=image;
      this.logo=logo;
      this.date=date;
      this.stock=stock;
      this.colour=colour;
  }
  public int getRno(){
    return rno;
    
}
 
  public String getName(){
    return name;
  
}
  public String getBrname()
  {
      return brname;
  }
  public int getPrice()
  {
      return price;
  }
          
  public byte[] getImage(){
    return image;
    
}
  public byte[] getLogo(){
    return logo;
    
}
  public String getColour(){
    return colour;
    
}
  public String getDate(){
    return date;
    
}
  public int getStock(){
    return stock;
    
}
  
}
  


